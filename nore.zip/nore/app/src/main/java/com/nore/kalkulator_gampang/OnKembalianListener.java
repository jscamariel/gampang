package com.nore.kalkulator_gampang;

public interface OnKembalianListener {
    public void onKembalian();
}
