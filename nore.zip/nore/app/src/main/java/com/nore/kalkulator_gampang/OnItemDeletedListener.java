package com.nore.kalkulator_gampang;

public interface OnItemDeletedListener {
    public void onItemDeleted();
}
